--
-- PostgreSQL database dump
--

\restrict ulz2SosiQ0cr9jATA94jFLzubWMhsE4QcghSC5XbRo5CWMmSzK0Z7aGxjHahgom

-- Dumped from database version 17.7 (Ubuntu 17.7-0ubuntu0.25.10.1)
-- Dumped by pg_dump version 17.7 (Ubuntu 17.7-0ubuntu0.25.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pinned_messages DROP CONSTRAINT IF EXISTS pinned_messages_pinned_by_fkey;
ALTER TABLE IF EXISTS ONLY public.pinned_messages DROP CONSTRAINT IF EXISTS pinned_messages_message_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_reply_to_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_chat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_reads DROP CONSTRAINT IF EXISTS message_reads_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_reads DROP CONSTRAINT IF EXISTS message_reads_message_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_reactions DROP CONSTRAINT IF EXISTS message_reactions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_reactions DROP CONSTRAINT IF EXISTS message_reactions_message_id_fkey;
ALTER TABLE IF EXISTS ONLY public.media DROP CONSTRAINT IF EXISTS media_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS chats_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS chats_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_members DROP CONSTRAINT IF EXISTS chat_members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_members DROP CONSTRAINT IF EXISTS chat_members_chat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_audit_log DROP CONSTRAINT IF EXISTS chat_audit_log_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_audit_log DROP CONSTRAINT IF EXISTS chat_audit_log_target_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_audit_log DROP CONSTRAINT IF EXISTS chat_audit_log_chat_id_fkey;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_last_seen_on_message ON public.messages;
DROP TRIGGER IF EXISTS update_chats_updated_at ON public.chats;
DROP TRIGGER IF EXISTS log_message_deletion_trigger ON public.messages;
DROP TRIGGER IF EXISTS enforce_private_chat_limit ON public.chat_members;
DROP INDEX IF EXISTS public.idx_users_username;
DROP INDEX IF EXISTS public.idx_users_status;
DROP INDEX IF EXISTS public.idx_users_phone;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_users_active;
DROP INDEX IF EXISTS public.idx_unique_chat_name_type;
DROP INDEX IF EXISTS public.idx_unique_active_pinned_message;
DROP INDEX IF EXISTS public.idx_unique_active_chat_member;
DROP INDEX IF EXISTS public.idx_pinned_messages_message;
DROP INDEX IF EXISTS public.idx_messages_sent_date;
DROP INDEX IF EXISTS public.idx_messages_sender;
DROP INDEX IF EXISTS public.idx_messages_reply;
DROP INDEX IF EXISTS public.idx_messages_pinned;
DROP INDEX IF EXISTS public.idx_messages_media;
DROP INDEX IF EXISTS public.idx_messages_deleted;
DROP INDEX IF EXISTS public.idx_messages_chat;
DROP INDEX IF EXISTS public.idx_message_reads_user;
DROP INDEX IF EXISTS public.idx_message_reads_message;
DROP INDEX IF EXISTS public.idx_message_reactions_user;
DROP INDEX IF EXISTS public.idx_message_reactions_message;
DROP INDEX IF EXISTS public.idx_media_user;
DROP INDEX IF EXISTS public.idx_media_upload_date;
DROP INDEX IF EXISTS public.idx_media_type;
DROP INDEX IF EXISTS public.idx_chat_members_user;
DROP INDEX IF EXISTS public.idx_chat_members_role;
DROP INDEX IF EXISTS public.idx_chat_members_chat;
DROP INDEX IF EXISTS public.idx_chat_audit_log_user;
DROP INDEX IF EXISTS public.idx_chat_audit_log_chat;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_phone_number_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_statuses DROP CONSTRAINT IF EXISTS user_statuses_status_name_key;
ALTER TABLE IF EXISTS ONLY public.user_statuses DROP CONSTRAINT IF EXISTS user_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.message_reactions DROP CONSTRAINT IF EXISTS unique_message_user_reaction;
ALTER TABLE IF EXISTS ONLY public.message_reads DROP CONSTRAINT IF EXISTS unique_message_read;
ALTER TABLE IF EXISTS ONLY public.pinned_messages DROP CONSTRAINT IF EXISTS pinned_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.message_reads DROP CONSTRAINT IF EXISTS message_reads_pkey;
ALTER TABLE IF EXISTS ONLY public.message_reactions DROP CONSTRAINT IF EXISTS message_reactions_pkey;
ALTER TABLE IF EXISTS ONLY public.media DROP CONSTRAINT IF EXISTS media_pkey;
ALTER TABLE IF EXISTS ONLY public.media DROP CONSTRAINT IF EXISTS media_file_url_key;
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS chats_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_types DROP CONSTRAINT IF EXISTS chat_types_type_name_key;
ALTER TABLE IF EXISTS ONLY public.chat_types DROP CONSTRAINT IF EXISTS chat_types_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_members DROP CONSTRAINT IF EXISTS chat_members_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_audit_log DROP CONSTRAINT IF EXISTS chat_audit_log_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_statuses ALTER COLUMN status_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pinned_messages ALTER COLUMN pin_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN message_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.message_reads ALTER COLUMN read_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.message_reactions ALTER COLUMN reaction_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.media ALTER COLUMN media_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chats ALTER COLUMN chat_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_types ALTER COLUMN type_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_members ALTER COLUMN member_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_audit_log ALTER COLUMN log_id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_user_id_seq;
DROP VIEW IF EXISTS public.user_unread_messages;
DROP SEQUENCE IF EXISTS public.user_statuses_status_id_seq;
DROP VIEW IF EXISTS public.user_statistics;
DROP TABLE IF EXISTS public.user_statuses;
DROP VIEW IF EXISTS public.user_active_chats;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.pinned_messages_pin_id_seq;
DROP TABLE IF EXISTS public.pinned_messages;
DROP SEQUENCE IF EXISTS public.messages_message_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.message_reads_read_id_seq;
DROP TABLE IF EXISTS public.message_reads;
DROP SEQUENCE IF EXISTS public.message_reactions_reaction_id_seq;
DROP TABLE IF EXISTS public.message_reactions;
DROP SEQUENCE IF EXISTS public.media_media_id_seq;
DROP TABLE IF EXISTS public.media;
DROP SEQUENCE IF EXISTS public.chats_chat_id_seq;
DROP TABLE IF EXISTS public.chats;
DROP SEQUENCE IF EXISTS public.chat_types_type_id_seq;
DROP TABLE IF EXISTS public.chat_types;
DROP SEQUENCE IF EXISTS public.chat_members_member_id_seq;
DROP TABLE IF EXISTS public.chat_members;
DROP SEQUENCE IF EXISTS public.chat_audit_log_log_id_seq;
DROP TABLE IF EXISTS public.chat_audit_log;
DROP FUNCTION IF EXISTS public.update_user_last_seen();
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP PROCEDURE IF EXISTS public.soft_delete_user(IN user_id_param integer);
DROP FUNCTION IF EXISTS public.log_message_deletion();
DROP FUNCTION IF EXISTS public.get_chat_member_count(chat_id_param integer);
DROP PROCEDURE IF EXISTS public.create_private_chat(IN user1_id integer, IN user2_id integer, OUT new_chat_id integer);
DROP FUNCTION IF EXISTS public.check_private_chat_members();
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: check_private_chat_members(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_private_chat_members() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    chat_type_name VARCHAR;
    member_count INTEGER;
BEGIN
    -- Get chat type
    SELECT ct.type_name INTO chat_type_name
    FROM chats c
    JOIN chat_types ct ON c.type_id = ct.type_id
    WHERE c.chat_id = NEW.chat_id;
    
    -- If this is a private chat
    IF chat_type_name = 'private' THEN
        -- Count active members
        SELECT COUNT(*) INTO member_count
        FROM chat_members
        WHERE chat_id = NEW.chat_id 
          AND left_at IS NULL;
        
        -- If already 2 members and trying to add a third
        IF member_count >= 2 THEN
            RAISE EXCEPTION 'Private chat cannot have more than 2 active members';
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: create_private_chat(integer, integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.create_private_chat(IN user1_id integer, IN user2_id integer, OUT new_chat_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Create chat
    INSERT INTO chats (type_id, created_by, is_private)
    VALUES (
        (SELECT type_id FROM chat_types WHERE type_name = 'private'),
        user1_id,
        TRUE
    )
    RETURNING chat_id INTO new_chat_id;
    
    -- Add members
    INSERT INTO chat_members (chat_id, user_id, role)
    VALUES 
        (new_chat_id, user1_id, 'owner'),
        (new_chat_id, user2_id, 'member');
END;
$$;


--
-- Name: get_chat_member_count(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_chat_member_count(chat_id_param integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    member_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO member_count
    FROM chat_members
    WHERE chat_id = chat_id_param AND left_at IS NULL;
    
    RETURN member_count;
END;
$$;


--
-- Name: log_message_deletion(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_message_deletion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.is_deleted = FALSE AND NEW.is_deleted = TRUE THEN
        INSERT INTO chat_audit_log (
            chat_id,
            user_id,
            action_type,
            target_user_id,
            old_value,
            new_value,
            performed_at
        ) VALUES (
            OLD.chat_id,
            OLD.sender_id,
            'message_deleted',
            NULL,
            OLD.content,
            NULL,
            CURRENT_TIMESTAMP
        );
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: soft_delete_user(integer); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.soft_delete_user(IN user_id_param integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Deactivate user
    UPDATE users 
    SET 
        is_active = FALSE,
        username = 'deleted_' || user_id_param || '_' || EXTRACT(EPOCH FROM CURRENT_TIMESTAMP),
        email = 'deleted_' || user_id_param || '_' || EXTRACT(EPOCH FROM CURRENT_TIMESTAMP) || '@deleted.local',
        phone_number = NULL,
        password_hash = '',
        avatar_url = NULL,
        status_id = (SELECT status_id FROM user_statuses WHERE status_name = 'offline'),
        updated_at = CURRENT_TIMESTAMP
    WHERE user_id = user_id_param;
    
    -- Remove user from chats
    UPDATE chat_members 
    SET left_at = CURRENT_TIMESTAMP
    WHERE user_id = user_id_param AND left_at IS NULL;
    
    -- Mark messages as deleted
    UPDATE messages 
    SET 
        is_deleted = TRUE,
        content = '[message deleted]',
        deleted_at = CURRENT_TIMESTAMP
    WHERE sender_id = user_id_param AND is_deleted = FALSE;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: update_user_last_seen(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_user_last_seen() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE users 
    SET last_seen = CURRENT_TIMESTAMP 
    WHERE user_id = NEW.sender_id;
    
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_audit_log (
    log_id integer NOT NULL,
    chat_id integer NOT NULL,
    user_id integer,
    action_type character varying(50) NOT NULL,
    target_user_id integer,
    old_value text,
    new_value text,
    ip_address inet,
    user_agent text,
    performed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_action_type CHECK (((action_type)::text = ANY ((ARRAY['user_joined'::character varying, 'user_left'::character varying, 'user_kicked'::character varying, 'user_banned'::character varying, 'role_changed'::character varying, 'chat_created'::character varying, 'chat_updated'::character varying, 'message_deleted'::character varying, 'permissions_changed'::character varying, 'invitation_sent'::character varying])::text[])))
);


--
-- Name: TABLE chat_audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.chat_audit_log IS 'Chat action audit log';


--
-- Name: chat_audit_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_audit_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_audit_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_audit_log_log_id_seq OWNED BY public.chat_audit_log.log_id;


--
-- Name: chat_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_members (
    member_id integer NOT NULL,
    chat_id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(20) DEFAULT 'member'::character varying,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    left_at timestamp without time zone,
    nickname_in_chat character varying(100),
    is_muted boolean DEFAULT false,
    is_banned boolean DEFAULT false,
    notifications_enabled boolean DEFAULT true,
    CONSTRAINT chat_members_role_check CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'moderator'::character varying, 'member'::character varying])::text[]))),
    CONSTRAINT chk_joined_left CHECK ((joined_at <= COALESCE((left_at)::timestamp with time zone, CURRENT_TIMESTAMP)))
);


--
-- Name: TABLE chat_members; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.chat_members IS 'Chat participants';


--
-- Name: chat_members_member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_members_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_members_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_members_member_id_seq OWNED BY public.chat_members.member_id;


--
-- Name: chat_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_types (
    type_id integer NOT NULL,
    type_name character varying(20) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE chat_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.chat_types IS 'Chat types (private, group, channel, broadcast)';


--
-- Name: chat_types_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_types_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_types_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_types_type_id_seq OWNED BY public.chat_types.type_id;


--
-- Name: chats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chats (
    chat_id integer NOT NULL,
    chat_name character varying(200),
    type_id integer NOT NULL,
    created_by integer NOT NULL,
    avatar_url character varying(500),
    description text,
    is_private boolean DEFAULT false,
    max_members integer DEFAULT 1000,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    CONSTRAINT chats_max_members_check CHECK ((max_members > 0))
);


--
-- Name: TABLE chats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.chats IS 'Chats and channels';


--
-- Name: chats_chat_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chats_chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chats_chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chats_chat_id_seq OWNED BY public.chats.chat_id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media (
    media_id integer NOT NULL,
    user_id integer NOT NULL,
    file_url character varying(500) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100),
    width integer,
    height integer,
    duration integer,
    thumbnail_url character varying(500),
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_encrypted boolean DEFAULT false,
    CONSTRAINT chk_file_size_limit CHECK ((file_size <= '10737418240'::bigint)),
    CONSTRAINT media_file_size_check CHECK ((file_size > 0))
);


--
-- Name: TABLE media; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.media IS 'Media files uploaded by users';


--
-- Name: media_media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_media_id_seq OWNED BY public.media.media_id;


--
-- Name: message_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reactions (
    reaction_id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    emoji character varying(10) NOT NULL,
    reacted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE message_reactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.message_reactions IS 'Message reactions';


--
-- Name: message_reactions_reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_reactions_reaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_reactions_reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_reactions_reaction_id_seq OWNED BY public.message_reactions.reaction_id;


--
-- Name: message_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reads (
    read_id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    read_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE message_reads; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.message_reads IS 'Message read receipts';


--
-- Name: message_reads_read_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_reads_read_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_reads_read_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_reads_read_id_seq OWNED BY public.message_reads.read_id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    message_id integer NOT NULL,
    chat_id integer NOT NULL,
    sender_id integer NOT NULL,
    reply_to_id integer,
    content text,
    media_id integer,
    is_edited boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    is_pinned boolean DEFAULT false,
    encryption_key character varying(500),
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delivered_at timestamp without time zone,
    read_at timestamp without time zone,
    edited_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT chk_content_or_media CHECK (((content IS NOT NULL) OR (media_id IS NOT NULL))),
    CONSTRAINT chk_message_timestamps CHECK (((sent_at <= COALESCE((delivered_at)::timestamp with time zone, CURRENT_TIMESTAMP)) AND (COALESCE(delivered_at, sent_at) <= COALESCE((read_at)::timestamp with time zone, CURRENT_TIMESTAMP)) AND (sent_at <= COALESCE((edited_at)::timestamp with time zone, CURRENT_TIMESTAMP)) AND (sent_at <= COALESCE((deleted_at)::timestamp with time zone, CURRENT_TIMESTAMP))))
);


--
-- Name: TABLE messages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.messages IS 'Messages in chats';


--
-- Name: messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_message_id_seq OWNED BY public.messages.message_id;


--
-- Name: pinned_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_messages (
    pin_id integer NOT NULL,
    message_id integer NOT NULL,
    pinned_by integer NOT NULL,
    pinned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    unpinned_at timestamp without time zone,
    reason text
);


--
-- Name: TABLE pinned_messages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.pinned_messages IS 'Pinned messages';


--
-- Name: pinned_messages_pin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pinned_messages_pin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pinned_messages_pin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pinned_messages_pin_id_seq OWNED BY public.pinned_messages.pin_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    phone_number character varying(20),
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    avatar_url character varying(500),
    status_id integer,
    last_seen timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_email_format CHECK (((email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text)),
    CONSTRAINT chk_phone_format CHECK ((((phone_number)::text ~* '^\+?[1-9]\d{1,14}$'::text) OR (phone_number IS NULL)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'Messenger users';


--
-- Name: user_active_chats; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_active_chats AS
 SELECT u.user_id,
    u.username,
    c.chat_id,
    c.chat_name,
    ct.type_name AS chat_type,
    count(cm.user_id) AS member_count,
    max(m.sent_at) AS last_message_time
   FROM ((((public.users u
     JOIN public.chat_members cm ON (((u.user_id = cm.user_id) AND (cm.left_at IS NULL))))
     JOIN public.chats c ON (((cm.chat_id = c.chat_id) AND (c.deleted_at IS NULL))))
     JOIN public.chat_types ct ON ((c.type_id = ct.type_id)))
     LEFT JOIN public.messages m ON (((c.chat_id = m.chat_id) AND (m.is_deleted = false))))
  WHERE (u.is_active = true)
  GROUP BY u.user_id, u.username, c.chat_id, c.chat_name, ct.type_name;


--
-- Name: user_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_statuses (
    status_id integer NOT NULL,
    status_name character varying(20) NOT NULL,
    is_online boolean DEFAULT false,
    description text
);


--
-- Name: TABLE user_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_statuses IS 'User statuses (online, offline, away, busy, invisible)';


--
-- Name: user_statistics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_statistics AS
 SELECT u.user_id,
    u.username,
    u.first_name,
    u.last_name,
    us.status_name,
    u.last_seen,
    count(DISTINCT cm.chat_id) AS active_chats_count,
    count(DISTINCT m.message_id) AS messages_sent,
    count(DISTINCT mr.message_id) AS messages_read
   FROM ((((public.users u
     LEFT JOIN public.user_statuses us ON ((u.status_id = us.status_id)))
     LEFT JOIN public.chat_members cm ON (((u.user_id = cm.user_id) AND (cm.left_at IS NULL))))
     LEFT JOIN public.messages m ON (((u.user_id = m.sender_id) AND (m.is_deleted = false))))
     LEFT JOIN public.message_reads mr ON ((u.user_id = mr.user_id)))
  WHERE (u.is_active = true)
  GROUP BY u.user_id, u.username, u.first_name, u.last_name, us.status_name, u.last_seen;


--
-- Name: user_statuses_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_statuses_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_statuses_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_statuses_status_id_seq OWNED BY public.user_statuses.status_id;


--
-- Name: user_unread_messages; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_unread_messages AS
 SELECT u.user_id,
    u.username,
    m.chat_id,
    c.chat_name,
    count(m.message_id) AS unread_count,
    max(m.sent_at) AS last_unread_time
   FROM ((((public.users u
     JOIN public.chat_members cm ON (((u.user_id = cm.user_id) AND (cm.left_at IS NULL))))
     JOIN public.chats c ON (((cm.chat_id = c.chat_id) AND (c.deleted_at IS NULL))))
     JOIN public.messages m ON (((c.chat_id = m.chat_id) AND (m.is_deleted = false) AND (m.sent_at > COALESCE(cm.joined_at, '1970-01-01 00:00:00'::timestamp without time zone)))))
     LEFT JOIN public.message_reads mr ON (((m.message_id = mr.message_id) AND (mr.user_id = u.user_id))))
  WHERE ((mr.read_id IS NULL) AND (m.sender_id <> u.user_id) AND (m.sent_at > COALESCE(cm.joined_at, '1970-01-01 00:00:00'::timestamp without time zone)))
  GROUP BY u.user_id, u.username, m.chat_id, c.chat_name;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: chat_audit_log log_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_audit_log ALTER COLUMN log_id SET DEFAULT nextval('public.chat_audit_log_log_id_seq'::regclass);


--
-- Name: chat_members member_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members ALTER COLUMN member_id SET DEFAULT nextval('public.chat_members_member_id_seq'::regclass);


--
-- Name: chat_types type_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_types ALTER COLUMN type_id SET DEFAULT nextval('public.chat_types_type_id_seq'::regclass);


--
-- Name: chats chat_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chats ALTER COLUMN chat_id SET DEFAULT nextval('public.chats_chat_id_seq'::regclass);


--
-- Name: media media_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media ALTER COLUMN media_id SET DEFAULT nextval('public.media_media_id_seq'::regclass);


--
-- Name: message_reactions reaction_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions ALTER COLUMN reaction_id SET DEFAULT nextval('public.message_reactions_reaction_id_seq'::regclass);


--
-- Name: message_reads read_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reads ALTER COLUMN read_id SET DEFAULT nextval('public.message_reads_read_id_seq'::regclass);


--
-- Name: messages message_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN message_id SET DEFAULT nextval('public.messages_message_id_seq'::regclass);


--
-- Name: pinned_messages pin_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_messages ALTER COLUMN pin_id SET DEFAULT nextval('public.pinned_messages_pin_id_seq'::regclass);


--
-- Name: user_statuses status_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_statuses ALTER COLUMN status_id SET DEFAULT nextval('public.user_statuses_status_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: chat_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_audit_log (log_id, chat_id, user_id, action_type, target_user_id, old_value, new_value, ip_address, user_agent, performed_at) FROM stdin;
\.


--
-- Data for Name: chat_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_members (member_id, chat_id, user_id, role, joined_at, left_at, nickname_in_chat, is_muted, is_banned, notifications_enabled) FROM stdin;
1	2	1	owner	2026-01-26 10:42:04.556607	\N	\N	f	f	t
2	2	2	admin	2026-01-26 10:42:04.556607	\N	\N	f	f	t
3	2	3	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
4	2	4	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
5	2	5	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
6	2	6	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
7	2	7	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
8	2	8	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
9	1	1	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
10	1	2	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
11	1	3	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
12	1	4	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
13	1	5	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
14	1	6	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
15	1	7	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
16	1	8	member	2026-01-26 10:42:04.556607	\N	\N	f	f	t
\.


--
-- Data for Name: chat_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_types (type_id, type_name, description, created_at) FROM stdin;
1	private	Private chat between two users	2026-01-26 10:42:04.359918
2	group	Group chat with multiple participants	2026-01-26 10:42:04.359918
3	channel	Channel with one sender and many subscribers	2026-01-26 10:42:04.359918
4	broadcast	Broadcast messages from one user to many	2026-01-26 10:42:04.359918
\.


--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chats (chat_id, chat_name, type_id, created_by, avatar_url, description, is_private, max_members, created_at, updated_at, deleted_at) FROM stdin;
1	Technical Support	3	2	\N	Official technical support channel.	f	1000	2026-01-26 10:42:04.556607	2026-01-26 10:42:04.556607	\N
2	General Messenger Chat	2	1	\N	Main chat for all users to communicate.	f	1000	2026-01-26 10:42:04.556607	2026-01-26 10:42:04.556607	\N
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media (media_id, user_id, file_url, file_name, file_type, file_size, mime_type, width, height, duration, thumbnail_url, uploaded_at, is_encrypted) FROM stdin;
\.


--
-- Data for Name: message_reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reactions (reaction_id, message_id, user_id, emoji, reacted_at) FROM stdin;
\.


--
-- Data for Name: message_reads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reads (read_id, message_id, user_id, read_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (message_id, chat_id, sender_id, reply_to_id, content, media_id, is_edited, is_deleted, is_pinned, encryption_key, sent_at, delivered_at, read_at, edited_at, deleted_at) FROM stdin;
1	2	1	\N	Welcome to Messenger!	\N	f	f	t	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
2	2	2	\N	For any questions, please contact support.	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
3	2	3	\N	Hello everyone!	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
4	2	4	\N	Greetings!	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
5	2	5	\N	Who wants to discuss technology?	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
6	2	6	\N	Great platform!	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
7	1	2	\N	Important update: technical maintenance tomorrow.	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
8	1	2	\N	New feature: voice messages.	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
9	1	2	\N	How to change avatar?	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
10	1	2	\N	We recommend enabling two-factor authentication.	\N	f	f	f	\N	2026-01-26 10:42:04.556607	\N	\N	\N	\N
\.


--
-- Data for Name: pinned_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_messages (pin_id, message_id, pinned_by, pinned_at, unpinned_at, reason) FROM stdin;
\.


--
-- Data for Name: user_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_statuses (status_id, status_name, is_online, description) FROM stdin;
1	online	t	User is online and active
2	offline	f	User is offline
3	away	f	User is away from device
4	busy	f	User is busy (do not disturb)
5	invisible	f	Invisible mode (online but status hidden)
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, username, email, phone_number, first_name, last_name, password_hash, avatar_url, status_id, last_seen, is_active, created_at, updated_at) FROM stdin;
0	system	system@messenger.internal	\N	System	Bot	22b5fe4145336d596fa83e7bf2dc60e19b6929e1b7fbc0a9523818df274c73bb	\N	1	\N	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.359918
7	eva	eva@example.com	\N	Eva	Green	496e97d83802ec7ad5a69391067c9faa0543ba84d686cbfa86783accbe35b881	\N	3	\N	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.359918
8	frank	frank@example.com	\N	Frank	Ocean	5530361577882c98df2eca384435b9208db768879c080d8412f27df28bf8fe79	\N	1	\N	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.359918
1	admin	admin@messenger.example.com	\N	System	Administrator	590d4a34fdde9c979fa1037bf774110b8555e666bafad663e6a0194f53a80b25	\N	1	2026-01-26 10:42:04.556607	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.556607
3	alice	alice@example.com	\N	Alice	Wonder	9a5846b5b0fcf1d5f85796cc91ae63950e880f39fe30e6a19b70f0793aa9958a	\N	1	2026-01-26 10:42:04.556607	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.556607
4	bob	bob@example.com	\N	Bob	Builder	f5ff9c6b4118fa2a55a05b007f315c7c4aea2d40e439e6df3843b6f61e2d9430	\N	1	2026-01-26 10:42:04.556607	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.556607
5	charlie	charlie@example.com	\N	Charlie	Chaplin	e6e93c78c9b875bf90041fbd40a2df7efa8eb9b4b29a2aed87469aa9931728c7	\N	2	2026-01-26 10:42:04.556607	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.556607
6	diana	diana@example.com	\N	Diana	Prince	2497935ca36ac111615d6ec6dcaf4b0f05299a503ee9a9d9c5bc9e94092e16b5	\N	1	2026-01-26 10:42:04.556607	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.556607
2	support	support@messenger.example.com	\N	Customer	Support	fcdd61096ae16962df7c7aec6539266fe62ba8edab60eb96062c51f45c50f387	\N	1	2026-01-26 10:42:04.556607	t	2026-01-26 10:42:04.359918	2026-01-26 10:42:04.556607
\.


--
-- Name: chat_audit_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_audit_log_log_id_seq', 1, false);


--
-- Name: chat_members_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_members_member_id_seq', 16, true);


--
-- Name: chat_types_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_types_type_id_seq', 4, true);


--
-- Name: chats_chat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chats_chat_id_seq', 2, true);


--
-- Name: media_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_media_id_seq', 1, false);


--
-- Name: message_reactions_reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_reactions_reaction_id_seq', 1, false);


--
-- Name: message_reads_read_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_reads_read_id_seq', 1, false);


--
-- Name: messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_message_id_seq', 10, true);


--
-- Name: pinned_messages_pin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pinned_messages_pin_id_seq', 1, false);


--
-- Name: user_statuses_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_statuses_status_id_seq', 5, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_id_seq', 8, true);


--
-- Name: chat_audit_log chat_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_audit_log
    ADD CONSTRAINT chat_audit_log_pkey PRIMARY KEY (log_id);


--
-- Name: chat_members chat_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_pkey PRIMARY KEY (member_id);


--
-- Name: chat_types chat_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_types
    ADD CONSTRAINT chat_types_pkey PRIMARY KEY (type_id);


--
-- Name: chat_types chat_types_type_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_types
    ADD CONSTRAINT chat_types_type_name_key UNIQUE (type_name);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (chat_id);


--
-- Name: media media_file_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_file_url_key UNIQUE (file_url);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (media_id);


--
-- Name: message_reactions message_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_pkey PRIMARY KEY (reaction_id);


--
-- Name: message_reads message_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_pkey PRIMARY KEY (read_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (message_id);


--
-- Name: pinned_messages pinned_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_pkey PRIMARY KEY (pin_id);


--
-- Name: message_reads unique_message_read; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT unique_message_read UNIQUE (message_id, user_id);


--
-- Name: message_reactions unique_message_user_reaction; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT unique_message_user_reaction UNIQUE (message_id, user_id, emoji);


--
-- Name: user_statuses user_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_statuses
    ADD CONSTRAINT user_statuses_pkey PRIMARY KEY (status_id);


--
-- Name: user_statuses user_statuses_status_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_statuses
    ADD CONSTRAINT user_statuses_status_name_key UNIQUE (status_name);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_number_key UNIQUE (phone_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_chat_audit_log_chat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_audit_log_chat ON public.chat_audit_log USING btree (chat_id, performed_at DESC);


--
-- Name: idx_chat_audit_log_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_audit_log_user ON public.chat_audit_log USING btree (user_id);


--
-- Name: idx_chat_members_chat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_members_chat ON public.chat_members USING btree (chat_id) WHERE (left_at IS NULL);


--
-- Name: idx_chat_members_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_members_role ON public.chat_members USING btree (role, chat_id);


--
-- Name: idx_chat_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_members_user ON public.chat_members USING btree (user_id) WHERE (left_at IS NULL);


--
-- Name: idx_media_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_media_type ON public.media USING btree (file_type);


--
-- Name: idx_media_upload_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_media_upload_date ON public.media USING btree (date(uploaded_at));


--
-- Name: idx_media_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_media_user ON public.media USING btree (user_id);


--
-- Name: idx_message_reactions_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_reactions_message ON public.message_reactions USING btree (message_id);


--
-- Name: idx_message_reactions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_reactions_user ON public.message_reactions USING btree (user_id);


--
-- Name: idx_message_reads_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_reads_message ON public.message_reads USING btree (message_id);


--
-- Name: idx_message_reads_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_reads_user ON public.message_reads USING btree (user_id);


--
-- Name: idx_messages_chat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_chat ON public.messages USING btree (chat_id, sent_at DESC);


--
-- Name: idx_messages_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_deleted ON public.messages USING btree (is_deleted) WHERE (is_deleted = false);


--
-- Name: idx_messages_media; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_media ON public.messages USING btree (media_id) WHERE (media_id IS NOT NULL);


--
-- Name: idx_messages_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_pinned ON public.messages USING btree (is_pinned) WHERE (is_pinned = true);


--
-- Name: idx_messages_reply; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_reply ON public.messages USING btree (reply_to_id) WHERE (reply_to_id IS NOT NULL);


--
-- Name: idx_messages_sender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_sender ON public.messages USING btree (sender_id);


--
-- Name: idx_messages_sent_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_sent_date ON public.messages USING btree (date(sent_at));


--
-- Name: idx_pinned_messages_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pinned_messages_message ON public.pinned_messages USING btree (message_id) WHERE (unpinned_at IS NULL);


--
-- Name: idx_unique_active_chat_member; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unique_active_chat_member ON public.chat_members USING btree (chat_id, user_id) WHERE (left_at IS NULL);


--
-- Name: idx_unique_active_pinned_message; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unique_active_pinned_message ON public.pinned_messages USING btree (message_id) WHERE (unpinned_at IS NULL);


--
-- Name: idx_unique_chat_name_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unique_chat_name_type ON public.chats USING btree (chat_name, type_id) WHERE ((deleted_at IS NULL) AND (chat_name IS NOT NULL));


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_active ON public.users USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone_number) WHERE (phone_number IS NOT NULL);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_status ON public.users USING btree (status_id) WHERE (is_active = true);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: chat_members enforce_private_chat_limit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER enforce_private_chat_limit BEFORE INSERT OR UPDATE ON public.chat_members FOR EACH ROW EXECUTE FUNCTION public.check_private_chat_members();


--
-- Name: messages log_message_deletion_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER log_message_deletion_trigger BEFORE UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.log_message_deletion();


--
-- Name: chats update_chats_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_chats_updated_at BEFORE UPDATE ON public.chats FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: messages update_last_seen_on_message; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_last_seen_on_message AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION public.update_user_last_seen();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: chat_audit_log chat_audit_log_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_audit_log
    ADD CONSTRAINT chat_audit_log_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(chat_id) ON DELETE CASCADE;


--
-- Name: chat_audit_log chat_audit_log_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_audit_log
    ADD CONSTRAINT chat_audit_log_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: chat_audit_log chat_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_audit_log
    ADD CONSTRAINT chat_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: chat_members chat_members_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(chat_id) ON DELETE CASCADE;


--
-- Name: chat_members chat_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: chats chats_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: chats chats_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.chat_types(type_id);


--
-- Name: media media_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: message_reactions message_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(message_id) ON DELETE CASCADE;


--
-- Name: message_reactions message_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: message_reads message_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(message_id) ON DELETE CASCADE;


--
-- Name: message_reads message_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: messages messages_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(chat_id) ON DELETE CASCADE;


--
-- Name: messages messages_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media(media_id) ON DELETE SET NULL;


--
-- Name: messages messages_reply_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_reply_to_id_fkey FOREIGN KEY (reply_to_id) REFERENCES public.messages(message_id) ON DELETE SET NULL;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(user_id);


--
-- Name: pinned_messages pinned_messages_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(message_id) ON DELETE CASCADE;


--
-- Name: pinned_messages pinned_messages_pinned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_pinned_by_fkey FOREIGN KEY (pinned_by) REFERENCES public.users(user_id);


--
-- Name: users users_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.user_statuses(status_id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict ulz2SosiQ0cr9jATA94jFLzubWMhsE4QcghSC5XbRo5CWMmSzK0Z7aGxjHahgom

